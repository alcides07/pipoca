#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

pair<int, int> solve(vector<int> &v, int s){
    for (int i=0 ; i<v.size() ; ++i)
        for (int j=i+1 ; j<v.size() ; ++j)
            if (v[i] + v[j] == s)
                return {i+1, j+1};
    return {-1, -1};
}

int main(){
    int n,s; cin >> n >> s;
    vector<int> v(n);
    for (auto &a:v) cin >> a;
    // sort(v.begin(),v.end());
    auto ans = solve(v, s);
    if (ans.first != -1)
        cout << ans.first << " " << ans.second << "\n";
    else
        cout << "IMPOSSIVEL\n";
    return 0;
}