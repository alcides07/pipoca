#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

pair<int, int> solve(vector<pair<int, int>>& v, int s) {
    int left = 0, right = v.size() - 1;
    while (left < right) {
        int sum = v[left].first + v[right].first;
        if (sum == s) return { v[left].second,v[right].second };
        if (sum < s) left++;
        else right--;
    }
    return { -1,-1 };
}

int main() {
    ios_base::sync_with_stdio(false);
    int n, s; cin >> n >> s;
    vector<pair<int, int>> v(n);
    for (int i = 0; i < n; ++i) {
        cin >> v[i].first;
        v[i].second = i + 1;
    }
    sort(v.begin(), v.end());
    auto ans = solve(v, s);
    if (ans.first != -1)
        cout << ans.first << " " << ans.second << endl;
    else
        cout << "IMPOSSIVEL\n";
    return 0;
}