def solve(lista, s):
    left = 0
    right = len(lista) - 1
    while left < right:
        if lista[left][0] + lista[right][0] == s:
            return (lista[left][1], lista[right][1])
        if lista[left][0] + lista[right][0] < s:
            left = left + 1
        else:
            right = right - 1
    return (-1, -1)


n, s = map(int, input().split())
l = list(map(int, input().split()))
lista = [(l[i], i+1) for i in range(len(l))]
lista.sort()
(i1, i2) = solve(lista, s)
if i1 != -1:
    print(i1, i2)
else:
    print("IMPOSSIVEL")
