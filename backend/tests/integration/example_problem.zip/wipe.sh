#!/usr/bin/env bash
#   *** tests ***
rm -f tests/01.a
rm -f tests/02.a
rm -f tests/03.a
rm -f tests/04.a
rm -f tests/05.a
rm -f tests/06.a
rm -f tests/07.a
rm -f tests/08.a
rm -f tests/09.a
rm -f tests/10
rm -f tests/10.a
rm -f tests/11
rm -f tests/11.a
rm -f tests/12
rm -f tests/12.a
rm -f tests/13
rm -f tests/13.a
rm -f tests/14
rm -f tests/14.a
rm -f tests/15
rm -f tests/15.a

