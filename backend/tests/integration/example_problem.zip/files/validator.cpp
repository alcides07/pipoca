#include "testlib.h"

using namespace std;
/*
10 28
2 4 6 8 10 12 14 16 18 20
*/
int main(int argc, char* argv[]) {
    registerValidation(argc, argv);
    int N = inf.readInt(2, 1'000'000, "N");
    inf.readSpace();
    int S = inf.readInt(1, 2'000'000'000, "S");
    inf.readEoln();
    inf.readInts(N,1,1'000'000'000,"a");
    inf.readEoln();
    inf.readEof();
    return 0;
}
