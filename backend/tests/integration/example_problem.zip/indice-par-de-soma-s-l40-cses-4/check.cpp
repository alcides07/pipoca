#include <bits/stdc++.h>
#include "testlib.h"


int main(int argc, char* argv[]) {
    setName("Check index");
    registerTestlibCmd(argc, argv);
    int n, s;
    n = inf.readInt();
    inf.readSpace();
    s = inf.readInt();
    auto a = inf.readInts(n);
    std::string  resp = ans.readLine();
    if (resp == "IMPOSSIVEL") {
        std::string ouf_ans = ouf.readLine();
        if (resp != ouf_ans)
            quitf(_wa, "Expected %s, found %s", resp.c_str(), ouf_ans.c_str());
        quitf(_ok, "Expected %s, found %s", resp.c_str(), ouf_ans.c_str());

    }
    else {
        std::pair<int, int> jans, pans;
        std::stringstream ss(resp, std::ios_base::in);
        ss >> jans.first >> jans.second;
        pans.first = ouf.readInt();
        ouf.readSpace();
        pans.second = ouf.readInt();
        int j_sum = a[jans.first - 1] + a[jans.second - 1];
        if (pans.first > a.size() or pans.second > a.size() or
            pans.first <= 0 or pans.second <= 0
            )
            quitf(_wa, "Invalid indeces: %d and %d!", pans.first, pans.second);
        int p_sum = a[pans.first - 1] + a[pans.second - 1];
        if (j_sum != s)
            quitf(_fail, "Jury wrong: %d + %d is not %d", a[jans.first - 1], a[jans.second - 1], s);
        if (p_sum != s)
            quitf(_wa, "a[%d] = %d and a[%d] = %d.  %d + %d is not %d!",
                pans.first, a[pans.first - 1],
                pans.second, a[pans.second - 1],
                a[pans.first - 1], a[pans.second - 1], s);
        if (pans.first == pans.second)
            quitf(_wa, "Indeces must differ. %d == %d!",
                pans.first,
                pans.second);

        quitf(_ok, "a[%d] = %d and a[%d] = %d.  %d + %d is %d!",
            pans.first, a[pans.first - 1],
            pans.second, a[pans.second - 1],
            a[pans.first - 1], a[pans.second - 1], s);
    }
}
