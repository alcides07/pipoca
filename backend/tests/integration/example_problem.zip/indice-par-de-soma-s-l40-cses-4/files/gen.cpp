
#include <iostream>
#include "testlib.h"

using namespace std;

/*
  gen TC N YES/NO
  TC = test case
  N = Number of elements to be generated
  YES/NO = Exists or not sum s on array
*/
int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int factor = 1, tc_num = stoi(argv[1]) - 1;
    int n = stoi(argv[2]) - 1;
    bool may_exist = string(argv[3]) == "YES";
    if (may_exist) factor = 2;
    int s = rnd.next(1, 2'000'000'000);
    if (not may_exist) s |= 1;
    cout << n << " " << s << "\n";
    int ai = rnd.next(1, 1'000'000'000);
    if (not may_exist) ai &= ((1<<30)-2);
    cout << ai;
    for (int i = 1; i < n; ++i) {
        int ai = rnd.next(1, 1'000'000'000);
        if (not may_exist) ai &= ((1<<30)-2);
        cout << " " << ai;
    }
    cout << "\n";
    return 0;
}
