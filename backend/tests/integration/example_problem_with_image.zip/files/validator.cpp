#include "testlib.h"

using namespace std;
/*
4
*/
int main(int argc, char* argv[]) {
    registerValidation(argc, argv);
    int n = inf.readInt(0, 10000, "n");
    inf.readEoln();
    inf.readEof();
    return 0;
}
