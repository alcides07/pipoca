
#include <iostream>
#include "testlib.h"

using namespace std;

vector<int> tc;

void gen_tc(){

    // test 1:1.in
    tc.push_back(9);
    // test 1:2.in
    tc.push_back(1);
    // test 1:3.in
    tc.push_back(3);
    // test 1:4.in
    tc.push_back(0);
    // test 1:5.in
    tc.push_back(11);
    // test 5:1.in
    tc.push_back(8712);
    // test 1:6.in
    tc.push_back(12);
    // test 1:7.in
    tc.push_back(5);
    // test 1:8.in
    tc.push_back(6);
    // test 1:9.in
    tc.push_back(8);
    // test 1:10.in
    tc.push_back(7);
    // test 1:11.in
    tc.push_back(4);
    // test 1:12.in
    tc.push_back(13);
    // test 1:13.in
    tc.push_back(10);
    // test 1:14.in
    tc.push_back(14);
    // test 1:15.in
    tc.push_back(2);
    // test 1:16.in
    tc.push_back(15);
    // test 1:17.in
    tc.push_back(16);
    // test 2:1.in
    tc.push_back(17);
    // test 2:2.in
    tc.push_back(20);
    // test 2:3.in
    tc.push_back(32);
    // test 2:4.in
    tc.push_back(40);
    // test 2:5.in
    tc.push_back(151);
    // test 2:6.in
    tc.push_back(45);
    // test 2:7.in
    tc.push_back(78);
    // test 2:8.in
    tc.push_back(92);
    // test 3:1.in
    tc.push_back(251);
    // test 3:2.in
    tc.push_back(435);
    // test 3:3.in
    tc.push_back(278);
    // test 3:4.in
    tc.push_back(101);
    // test 4:1.in
    tc.push_back(1251);
    // test 4:2.in
    tc.push_back(4235);
    // test 4:3.in
    tc.push_back(2078);
    // test 4:4.in
    tc.push_back(1301);
    // test 5:2.in
    tc.push_back(6078);
    // test 5:3.in
    tc.push_back(7301);
    // test 5:4.in
    tc.push_back(9571);
    // test 5:5.in
    tc.push_back(9997);
    // test 5:6.in
    tc.push_back(9998);
    // test 5:7.in
    tc.push_back(9999);
    // test 5:8.in
    tc.push_back(10000);

}

int main(int argc, char *argv[]){
    registerGen(argc, argv, 1);
    gen_tc();
    int tc_num = stoi(argv[1])-1;
    int n = tc[tc_num];
    cout << n << "\n";
    return 0;
}
