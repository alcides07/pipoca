#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

bool check_ans(int a, int b, InStream &stream) {
    int gabarito;
    gabarito = stream.readInt(-10000, 10000, "gabarito");
    return a * b == gabarito;
}

int main(int argc, char *argv[]) {
    setName("Corretor de leitura de dois números inteiros que verifica o produto entre eles");
    registerTestlibCmd(argc, argv);
    int a = inf.readInt(-100, 100, "a");
    int b = inf.readInt(-100, 100, "b");
    bool ans_juiz = check_ans(a, b, ans);
    bool ans_participante = check_ans(a, b, ouf);
    if (!ans_juiz) {
        quitf(_fail, "A resposta do juiz está incorreta!\n");
    } else if (!ans_participante) {
        quitf(_wa, "A resposta do participante está incorreta!\n");
    }
    quitf(_ok, "Resposta correta!\n"); 
    return 0;
}
